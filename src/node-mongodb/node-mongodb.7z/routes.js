module.exports = function (app) {
    app.use('/api/customer', require('./api/Customer'))
}
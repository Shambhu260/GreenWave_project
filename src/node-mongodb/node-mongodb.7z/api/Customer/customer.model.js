const mongoose = require("mongoose")
const customerSchema = new mongoose.Schema({
    customerName: {type: String, required: true},
    customerId: {type: String,default: "ABC000"},
    email: {type: String, trim: true,
        unique: 'Email already exists',
        match: [/.+\@.+\..+/, 'Please fill a valid email address'],
        required: 'Email is required',},
    phone: {type: Number},
    address: {type: String},
    dob: {type: Date},
    total_spent: {type: String, required: true},
    createdBy: {type: String},
    createdAt: { type: Date, required: true, default: Date.now()},
    updateBy: {type: String},
    updateAt: {type: Date, required: true, default: Date.now()},
})
module.exports = mongoose.model("customer", customerSchema, "customer")
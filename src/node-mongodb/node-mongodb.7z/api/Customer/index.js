const express = require("express");
const controller = require("../Customer/customer.controller")
const router = express.Router();

router.post("/register", controller.register)
router.get("/getAllCustomer", controller.getAllCustomer)
router.put("/updateCustomer/:empId", controller.updateCustomer)
router.delete("/deleteCustomer/:empId", controller.deleteCustomer)
router.get("/getSingleData/:empId", controller.getSingleData);
router.post("/login", controller.login)
router.get("/download_entire_data", controller.download_entire_data)
router.get("/download_birthdays", controller.download_birthdays)
router.get("/download_high_spenders", controller.download_high_spenders)
module.exports = router